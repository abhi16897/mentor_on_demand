import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { skills } from '../home/skills';
import { Observable, Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MentorDetailsService {
  filter = new Subject();
  private subject=new Subject<skills[]>();
  constructor(private httpClient:HttpClient) { }

getAllmentorDetails():Observable<any>{
    return this.httpClient.get<skills[]>('http://localhost:9804/details');
}
getSubject():Subject<skills[]>{
  return this.subject;
}
}
