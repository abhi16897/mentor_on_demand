import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isLoginValid = true;
  
  constructor(private authenticationService: AuthenticationService) { }

  ngOnInit() {
  }
  onSubmit(form: NgForm){
    const username = form.value.username;
    const password = form.value.password;
    console.log(username+" "+password);
    this.authenticationService.authenticate(username,password).subscribe((data)=>{
      console.log(data);

      if(data.Role=='Mentor'){
          this.authenticationService.isMentor=true
          
      }
      else if(data.Role=='Student'){
          this.authenticationService.isStudent=true
      }
    });

  }

}
