export interface Technology{
    name:String;
    tableOfContents:String
    duration:number
    prerequisites:String
}