import { Component, OnInit, Input } from '@angular/core';
import { skills } from '../skills';

@Component({
  selector: 'app-mentor-info',
  templateUrl: './mentor-info.component.html',
  styleUrls: ['./mentor-info.component.css']
})
export class MentorInfoComponent implements OnInit {
  @Input() mentor:skills
  constructor() { }

  ngOnInit() {
  }

}
